export const firebaseConfig = {
  apiKey: "PEGAR_API_KEY_AQUI",
  authDomain: "PEGAR_PROJECT_ID.firebaseapp.com",
  projectId: "PEGAR_PROJECT_ID",
  storageBucket: "PEGAR_PROJECT_ID.appspot.com",
  messagingSenderId: "PEGAR_SENDER_ID",
  appId: "PEGAR_APP_ID"
};
